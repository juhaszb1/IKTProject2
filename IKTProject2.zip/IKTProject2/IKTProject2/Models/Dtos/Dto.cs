﻿namespace IKTProject2.Models.Dtos
{
    public record MusicDto(int Id, string Name, int PublicationYear, string Performer, int GenreId);
    public record PostMusicDto(string Name, int PublicationYear, string Perfomer, int GenreId);
    public record PutMusicDto(string Name, int PublicationYear, string Performer, int GenreId);
    public record GenreDto(int Id, string Name);
    public record PostGenreDto(string Name);
    public record PutGenreDto(string Name);
}
