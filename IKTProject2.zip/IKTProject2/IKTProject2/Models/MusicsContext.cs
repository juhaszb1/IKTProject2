﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace IKTProject2.Models;

public partial class MusicsContext : DbContext
{
    public MusicsContext()
    {
    }

    public MusicsContext(DbContextOptions<MusicsContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Genre> Genres { get; set; } = null!;

    public virtual DbSet<Music> Musics { get; set; } = null!;

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseMySQL("SERVER=localhost;PORT=3306;DATABASE=musics;USER=root;PASSWORD=;SSL MODE=none;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Genre>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("genre");

            entity.Property(e => e.Id).HasColumnType("int(11)");
            entity.Property(e => e.Name)
                .HasMaxLength(64)
                .HasDefaultValueSql("'NULL'");
        });

        modelBuilder.Entity<Music>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("music");

            entity.HasIndex(e => e.GenreId, "GenreId");

            entity.Property(e => e.Id).HasColumnType("int(11)");
            entity.Property(e => e.GenreId)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");
            entity.Property(e => e.Name)
                .HasMaxLength(64)
                .HasDefaultValueSql("'NULL'");
            entity.Property(e => e.Performer)
                .HasMaxLength(64)
                .HasDefaultValueSql("'NULL'");
            entity.Property(e => e.PublicationYear)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");

            entity.HasOne(d => d.Genre).WithMany(p => p.Musics)
                .HasForeignKey(d => d.GenreId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("music_ibfk_1");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
