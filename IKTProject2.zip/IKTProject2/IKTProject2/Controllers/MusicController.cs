﻿using IKTProject2.Models;
using IKTProject2.Models.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace IKTProject2.Controllers
{
    [Route("music")]
    [ApiController]
    public class MusicController : ControllerBase
    {
        [HttpGet]
        public ActionResult<Music> GetMusic() 
        {
            using (var context = new MusicsContext())
            {
                try
                {
                    var result = context.Musics.ToList();
                    return Ok(result);
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpGet("{id}")]
        public ActionResult<Music> GetMusicWithId(int id) 
        {
            using (var context = new MusicsContext())
            {
                try
                {
                    var result = context.Musics.Where(x => x.Id == id).ToList();
                    return Ok(result);
            }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPost]
        public ActionResult<Music> PostMusic(PostMusicDto postMusicDto) 
        {
            var music = new Music
            {
                Name = postMusicDto.Name,
                PublicationYear = postMusicDto.PublicationYear,
                Performer = postMusicDto.Perfomer,
                GenreId = postMusicDto.GenreId
            };
            using (var context = new MusicsContext())
            {
                try
                {
                    context.Musics.Add(music);
                    context.SaveChanges();
                    return Ok("Sikeres adathozzáadás!");
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPut("{id}")]
        public ActionResult<Music> PutMusic(int id, PutMusicDto putMusicDto)
        {
            using (var context = new MusicsContext())
            {
                var changedMusic = context.Musics.FirstOrDefault(x => x.Id == id);
                try
                {
                    changedMusic!.Name = putMusicDto.Name;
                    changedMusic.PublicationYear = putMusicDto.PublicationYear;
                    changedMusic.Performer = putMusicDto.Performer;
                    changedMusic.GenreId = putMusicDto.GenreId;
                    context.Musics.Update(changedMusic);
                    context.SaveChanges();
                    return Ok("Sikeres módosítás!");
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpDelete("{id}")]
        public ActionResult<Music> DeleteMusic(int id) 
        {
            using (var context = new MusicsContext())
            {
                try
                {
                    var deletedMusic = context.Musics.FirstOrDefault(x => x.Id == id);
                    context.Musics.Remove(deletedMusic!);
                    context.SaveChanges();
                    return Ok("Sikeres törlés!");
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }
    }
}