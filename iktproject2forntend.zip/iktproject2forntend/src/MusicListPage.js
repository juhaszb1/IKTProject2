import { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import './App.css';

export default function MusicListPage() {
    const [musics, setMusics] = useState([]);

    useEffect(() => {
        fetch("https://localhost:7126/music")
            .then((response) => response.json())
            .then((data) => setMusics(data))
            .catch((error) => console.log(error));
    }, []);

    return (
        <div className="container">
            <div className="row">
                <h2>Musics</h2>
                {musics.map((music) => (
                    <div className="card col-md-4 cards" style={{ width: "18rem", backgroundColor: "#1DB954" }}>
                        <div className="card-body">
                            <h5 className="card-title">{music.name}</h5>
                            <h5 className="card-title">{music.publicationYear}</h5>
                            <h5 className="card-title">{music.performer}</h5>
                            <h5 className="card-title">Genre Id: {music.genreId}</h5>
                            <NavLink>
                                <button className="btn btn-warning">Módosítás</button>
                            </NavLink>
                            <NavLink>
                                <button className="btn btn-danger">Törlés</button>
                            </NavLink>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}