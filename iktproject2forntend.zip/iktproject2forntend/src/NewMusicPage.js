import { useNavigate } from "react-router-dom";

export default function NewMusicPage() {
    const navigate = useNavigate();

    return (
        <div>
            <h2>New Music</h2>
            <form onSubmit={(e) => {
                e.preventDefault();
                fetch("https://localhost:7126/music", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        name: e.target.name.value,
                        publicationYear: e.target.publicationYear.value,
                        performer: e.target.performer.value,
                        genreId: e.target.genreId.value
                    })
                })
                    .then(() => {
                        navigate("/");
                    }).catch((error) => console.log(error));
            }}>
                <div className="form-group row pb-3">
                    <label className="col-sm-3 col-form-label">Name:</label>
                    <div>
                        <input type="text" name="name" className="form-control" />
                    </div>
                </div>
                <div className="form-group row pb-3">
                    <label className="col-sm-3 col-form-label">Publication Year:</label>
                    <div>
                        <input type="number" name="publicationYear" className="form-control" />
                    </div>
                </div>
                <div className="form-group row pb-3">
                    <label className="col-sm-3 col-form-label">Performer:</label>
                    <div>
                        <input type="text" name="performer" className="form-control" />
                    </div>
                </div>
                <div className="form-group row pb-3">
                    <label className="col-sm-3 col-form-label">Genre Id:</label>
                    <div>
                        <input type="number" name="genreId" className="form-control" />
                    </div>
                </div>
                <button type="submit" className="btn btn-success">Küldés</button>
            </form>
        </div>
    );
}