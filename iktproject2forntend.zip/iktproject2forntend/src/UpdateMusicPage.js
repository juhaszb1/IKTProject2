import { useParams } from "react-router-dom";

export default function UpdateMusicPage() {
    const { id } = useParams();
    
}