import { useState, useEffect } from "react";
//import { NavLink } from "react-router-dom";

export default function MusicListPage() {
    const [musics, setMusics] = useState([]);
    const [isFetchPending, setFetchPending] = useState(false);

    useEffect(() => {
        setFetchPending(true);
        fetch("https://localhost:7126/music", { credentials: "include" })
            .then((response) => response.json())
            .then((data) => setMusics(data))
            .finally(() => setFetchPending(false));
    }, []);

    return (
        <div className='p-5 m-auto text-center content bg-ivory'>
            {isFetchPending ? (<div className='spinner-border'></div>) : (
                <div>
                    <h2>Hangszerek</h2>
                    {musics.map((music) => (
                        <div class="card" style={{ width: "18rem" }}>
                            <div class="card-body">
                                <h5 class="card-title">{music.name}</h5>
                                <h5 class="card-title">{music.publicationYear}</h5>
                                <h5 class="card-title">{music.performer}</h5>
                                <h5 class="card-title">{music.genreId}</h5>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}